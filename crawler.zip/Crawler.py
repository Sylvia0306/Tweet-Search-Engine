import tweepy
import config
import config_sylvia
import time
import json
import sys

auth = tweepy.OAuth1UserHandler( config.api_key, config.api_secret, config.access_token, config.access_token_secret )
#auth = tweepy.OAuth1UserHandler( config_sylvia.api_key, config_sylvia.api_secret, config_sylvia.access_token, config_sylvia.access_token_secret )
api = tweepy.API(auth)

# friends_ids 15 limits
# user_timeline 900 limits
# get_user 900

counter_get_user = 0
counter_user_timeline = 0
counter_get_frineds = 0

def Verified( api, id, counter_get_user ) :
    counter_get_user += 1
    verified = api.get_user( user_id = id )
    if ( verified.verified == True ) :
        return True
    else :
        return False


def CollectID_Name( api, screenname, counter_get_user ) :
    counter_get_user += 1
    id_list = api.get_friend_ids( screen_name=screenname )
    return id_list

def CollectID_ID( api, id, counter_get_frineds ) :
    counter_get_frineds = counter_get_frineds + 1
    id_list = api.get_friend_ids( user_id=id )
    return id_list

def WriteJson( filename, dict ) :
    dump_json = json.dumps( dict, default=str )
    with open( str( filename ), "a+" ) as outfile :
        outfile.write( dump_json )
        outfile.write( '\n' )


def WriteText( filename, list ) :
    for item in list :
        with open( str( filename ), 'a+' ) as f :
            f.write( str( item ) )
            f.write('\n')


def CollectTweets( api, id, counter_get_user, counter_user_timeline, filename ) :
    # collect tweets from specific id
    counter_get_user += 1
    response = api.get_user( user_id=id )
    columns = ['TweetId', 'User', 'text', 'Date']
    counter_user_timeline += 1
    tweets = api.user_timeline( id = response.id, count = 200 )


    for tweet in tweets :
        if ( tweet.place != None ) :
            if ( tweet.entities != None ) : 
                if ( len( tweet.entities['hashtags'] ) > 0 ) :
                    tweet_dict = { "Tweet_ID": tweet.id, "User": tweet.user.screen_name, "Text": tweet.text, 
                        "City": tweet.place.name, "Country": tweet.place.country, 
                        "Coordinates": tweet.place.bounding_box.coordinates, "Entities": tweet.entities,
                        "Date": tweet.created_at }
                else :
                    tweet_dict = { "Tweet_ID": tweet.id, "User": tweet.user.screen_name, "Text": tweet.text, 
                        "City": "null", "Country": "null", 
                        "Coordinates": "null", "Entities": tweet.entities,
                        "Date": tweet.created_at }

            else :
                tweet_dict = { "Tweet_ID": tweet.id, "User": tweet.user.screen_name, "Text": tweet.text, 
                        "City": tweet.place.name, "Country": tweet.place.country, 
                        "Coordinates": tweet.place.bounding_box.coordinates, "Entities": "null",
                        "Date": tweet.created_at }

            WriteJson( filename, tweet_dict )
        else :
            if ( tweet.entities != None ) :
                if ( len( tweet.entities['hashtags'] ) > 0 ) :
                    tweet_dict = { "Tweet_ID": tweet.id, "User": tweet.user.screen_name, "Text": tweet.text, 
                        "City": "null", "Country": "null", 
                        "Coordinates": "null", "Entities": tweet.entities,
                        "Date": tweet.created_at }
                else :
                    tweet_dict = { "Tweet_ID": tweet.id, "User": tweet.user.screen_name, "Text": tweet.text, 
                        "City": "null", "Country": "null", 
                        "Coordinates": "null", "Entities": tweet.entities,
                        "Date": tweet.created_at }

            else :
                tweet_dict = { "Tweet_ID": tweet.id, "User": tweet.user.screen_name, "Text": tweet.text, 
                        "City": "null", "Country": "null", 
                        "Coordinates": "null", "Entities": "null",
                        "Date": tweet.created_at }

            WriteJson( filename, tweet_dict )



def GetUserID( filename, accounts= "sundarpichai" ) :
    print( "Collecting ids..." )
    filename = filename + ".txt"
    temp_list = CollectID_Name( api, str( accounts ), counter_get_user )
    d_list = []
    verified_id = []
    for id in temp_list :
        print( "Verified ids..." )
        if ( Verified( api, id, counter_get_user ) ) :
            verified_id.append(id)

    for i in range( 10 ) :
        print( "Adding ids..." )
        d_list.append( CollectID_ID( api, verified_id[i], counter_get_frineds ) )
    d_list.append( temp_list )

    for i in range( len( d_list ) ) :
        print( "Writing ids..." )
        WriteText( filename, d_list[i] )


def Crawler( filename, twitter_id, num ) :
    filename = filename + ".json"
    twitter_id = twitter_id + ".txt"
    list = []
    with open( str( twitter_id ), 'r' ) as f :
        for line in f.readlines() :
            line = line[:-1]
            list.append( line )

    
    if ( int( num ) <= len( list ) * 200 ) :
        for i in range( int ( int( num ) / 200 ) ) :
            # prevent exceed the limit
            if ( counter_get_user <= 800 and counter_get_frineds < 11 and counter_user_timeline <= 800 ) :
                try:
                    CollectTweets( api, list[i], counter_get_user, counter_user_timeline, filename )
                except:
                    print( "An exception occurred" )
            else :
                # hang 15mins

                will = input( "sleep for 15mins because we meet limit are you willing to continue? 'y' or 'n': " )
                if ( will == 'y' ) :
                    time.sleep( 900 )
                else :
                    break
    else :
        print( "Out of numbers of tweets!" )
    

def main():
    # python3 Crawler.py tweets_id tweets
    tweets_id_file = sys.argv[1]
    tweets_file = sys.argv[2]
    check = input( "If you want choose your entrypoint of crawler please enter 'y' other enter 'n' : " )
    if ( check == 'y' ) :
        accounts = input( "Account name:" )
        GetUserID( tweets_file, accounts )
    else :
        # use default value (sundarpichai) as entrypoint
        GetUserID( tweets_file )

    num = input( "Numbers of tweets you want crawl : " )
    Crawler( tweets_id_file, tweets_file, num )


# To use our crawler, please go to /home/cs242/CS242/ directory
# and launch the program
# here's the instruction how to use our crawler

# python3 Crawler.py [tweets_id] [tweets]
# tweets_id is the output file of twitter user id text file
# tweets is the output file of tweets json file
# when we launch the program, the crawler would ask you would like to choose your entrypoint ?
# if yes, it would let user type the account name 
# if no, it would use 'sundarpichai' as entrypoint
if __name__ == "__main__":
    main()