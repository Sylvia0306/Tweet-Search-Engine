# used for store keys and secrets

api_key = "bFUBx6rDvk1vPQSNnn2PvCXzD"
api_secret = "02xI2PZQr9d1jtPEFUHCEaxqLKZBNp5ssEtpFulycnx1iVlFYz"

access_token = "2357670384-nDiJhyWqUbAIEr0hoxoBnyIlDSxzeOEnk7ouckj"
access_token_secret = "xd6ag57i2iD6NX2zEJ86ZBfyCYt3IGZ3ZI7E7ayb6Wfwd"
bearer_token ='AAAAAAAAAAAAAAAAAAAAAGejlQEAAAAA5eNOwyCtsMAAN07clsLW%2BVHMEa4%3DlT9UYwKUGl59R1ACSLnIa7rIJicoJfBsaWf3p8XH4RHfNGbeht'

OAuth2_Client_ID = "M1ZudHBRQzVBZVlJelJEQUcwLUE6MTpjaQ"
OAuth2_Client_Secret = "Em3vUZE-9MFSimGAHAqYOszh3cPNLiBW7oCOLBck0lmjSbp7Gs" 